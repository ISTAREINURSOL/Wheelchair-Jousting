The Funny >:)
